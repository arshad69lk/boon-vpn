import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0F172A),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const BoonVpnApp());
}

// ============================================================================
// MODEL: V2Ray Configuration & Parser
// ============================================================================
enum V2RayProtocol { vmess, vless, trojan, shadowsocks, customJson }

class V2RayConfig {
  final String id;
  String name;
  final V2RayProtocol protocol;
  String address;
  int port;
  String uuidOrPassword;
  String network; // tcp, ws, grpc
  String security; // none, tls, reality
  String path;
  String host;
  String sni;
  String rawUrl;
  int? lastPingMs;
  bool isConnected;

  V2RayConfig({
    required this.id,
    required this.name,
    required this.protocol,
    required this.address,
    required this.port,
    required this.uuidOrPassword,
    this.network = 'tcp',
    this.security = 'none',
    this.path = '',
    this.host = '',
    this.sni = '',
    required this.rawUrl,
    this.lastPingMs,
    this.isConnected = false,
  });

  /// Factory parser for various V2Ray URI formats
  static V2RayConfig? parse(String rawInput) {
    final trimmed = rawInput.trim();
    if (trimmed.isEmpty) return null;

    try {
      if (trimmed.startsWith('vmess://')) {
        return _parseVmess(trimmed);
      } else if (trimmed.startsWith('vless://')) {
        return _parseVless(trimmed);
      } else if (trimmed.startsWith('trojan://')) {
        return _parseTrojan(trimmed);
      } else if (trimmed.startsWith('ss://')) {
        return _parseShadowsocks(trimmed);
      } else if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
        return _parseJson(trimmed);
      }
    } catch (e) {
      debugPrint('Parsing error: $e');
    }
    return null;
  }

  static V2RayConfig _parseVmess(String url) {
    final base64Part = url.substring('vmess://'.length);
    final normalized = base64.normalize(base64Part.replaceAll('\n', '').replaceAll('\r', ''));
    final jsonStr = utf8.decode(base64.decode(normalized));
    final Map<String, dynamic> data = jsonDecode(jsonStr);

    return V2RayConfig(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: data['ps'] ?? 'VMess Server',
      protocol: V2RayProtocol.vmess,
      address: data['add'] ?? '',
      port: int.tryParse(data['port']?.toString() ?? '443') ?? 443,
      uuidOrPassword: data['id'] ?? '',
      network: (data['net'] ?? 'tcp').toString().toLowerCase(),
      security: (data['tls'] ?? 'none').toString().toLowerCase(),
      path: data['path'] ?? '',
      host: data['host'] ?? '',
      sni: data['sni'] ?? data['host'] ?? '',
      rawUrl: url,
    );
  }

  static V2RayConfig _parseVless(String url) {
    final uri = Uri.parse(url);
    final query = uri.queryParameters;
    final userInfo = uri.userInfo;
    final fragment = Uri.decodeComponent(uri.fragment.isEmpty ? 'VLESS Server' : uri.fragment);

    return V2RayConfig(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: fragment,
      protocol: V2RayProtocol.vless,
      address: uri.host,
      port: uri.port == 0 ? 443 : uri.port,
      uuidOrPassword: userInfo,
      network: (query['type'] ?? 'tcp').toLowerCase(),
      security: (query['security'] ?? 'none').toLowerCase(),
      path: query['path'] ?? '',
      host: query['host'] ?? '',
      sni: query['sni'] ?? query['host'] ?? '',
      rawUrl: url,
    );
  }

  static V2RayConfig _parseTrojan(String url) {
    final uri = Uri.parse(url);
    final query = uri.queryParameters;
    final fragment = Uri.decodeComponent(uri.fragment.isEmpty ? 'Trojan Server' : uri.fragment);

    return V2RayConfig(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: fragment,
      protocol: V2RayProtocol.trojan,
      address: uri.host,
      port: uri.port == 0 ? 443 : uri.port,
      uuidOrPassword: uri.userInfo,
      network: (query['type'] ?? 'tcp').toLowerCase(),
      security: (query['security'] ?? 'tls').toLowerCase(),
      path: query['path'] ?? '',
      host: query['host'] ?? '',
      sni: query['sni'] ?? query['host'] ?? '',
      rawUrl: url,
    );
  }

  static V2RayConfig _parseShadowsocks(String url) {
    final uri = Uri.parse(url);
    final fragment = Uri.decodeComponent(uri.fragment.isEmpty ? 'Shadowsocks Server' : uri.fragment);
    String host = uri.host;
    int port = uri.port;
    String password = '';

    if (host.isEmpty) {
      final b64 = url.substring('ss://'.length).split('#').first;
      final decoded = utf8.decode(base64.decode(base64.normalize(b64)));
      final atSplit = decoded.split('@');
      if (atSplit.length == 2) {
        final hostPort = atSplit[1].split(':');
        host = hostPort[0];
        port = int.tryParse(hostPort[1]) ?? 8388;
        password = atSplit[0];
      }
    } else {
      final decodedUserInfo = utf8.decode(base64.decode(base64.normalize(uri.userInfo)));
      password = decodedUserInfo;
    }

    return V2RayConfig(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: fragment,
      protocol: V2RayProtocol.shadowsocks,
      address: host,
      port: port == 0 ? 8388 : port,
      uuidOrPassword: password,
      network: 'tcp',
      security: 'none',
      rawUrl: url,
    );
  }

  static V2RayConfig _parseJson(String jsonStr) {
    return V2RayConfig(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: 'Custom JSON Config',
      protocol: V2RayProtocol.customJson,
      address: '127.0.0.1',
      port: 10808,
      uuidOrPassword: '',
      rawUrl: jsonStr,
    );
  }

  Map<String, dynamic> toV2rayJson({
    int localSocksPort = 10808,
    int localHttpPort = 10809,
    bool bypassLan = true,
  }) {
    if (protocol == V2RayProtocol.customJson) {
      return jsonDecode(rawUrl);
    }

    final Map<String, dynamic> outbound = {
      'tag': 'proxy',
      'protocol': protocol.name,
      'settings': _buildProtocolSettings(),
      'streamSettings': _buildStreamSettings(),
    };

    final List<Map<String, dynamic>> routingRules = [
      {
        'type': 'field',
        'outboundTag': 'direct',
        'domain': ['geosite:cn', 'geosite:private', 'domain:apple.com'],
      },
    ];

    if (bypassLan) {
      routingRules.add({
        'type': 'field',
        'outboundTag': 'direct',
        'ip': ['geoip:private', 'geoip:cn'],
      });
    }

    routingRules.add({
      'type': 'field',
      'outboundTag': 'proxy',
      'port': '0-65535',
    });

    return {
      'log': {'loglevel': 'warning'},
      'inbounds': [
        {
          'tag': 'socks-in',
          'port': localSocksPort,
          'listen': '127.0.0.1',
          'protocol': 'socks',
          'settings': {'auth': 'noauth', 'udp': true},
          'sniffing': {
            'enabled': true,
            'destOverride': ['http', 'tls']
          }
        },
        {
          'tag': 'http-in',
          'port': localHttpPort,
          'listen': '127.0.0.1',
          'protocol': 'http',
          'settings': {}
        }
      ],
      'outbounds': [
        outbound,
        {'tag': 'direct', 'protocol': 'freedom', 'settings': {}},
        {
          'tag': 'block',
          'protocol': 'blackhole',
          'settings': {'response': {'type': 'http'}}
        }
      ],
      'routing': {
        'domainStrategy': 'IPIfNonMatch',
        'rules': routingRules,
      },
      'dns': {
        'servers': ['1.1.1.1', '8.8.8.8', 'https://dns.google/dns-query']
      }
    };
  }

  Map<String, dynamic> _buildProtocolSettings() {
    switch (protocol) {
      case V2RayProtocol.vmess:
        return {
          'vnext': [
            {
              'address': address,
              'port': port,
              'users': [
                {'id': uuidOrPassword, 'alterId': 0, 'security': 'auto'}
              ]
            }
          ]
        };
      case V2RayProtocol.vless:
        return {
          'vnext': [
            {
              'address': address,
              'port': port,
              'users': [
                {'id': uuidOrPassword, 'encryption': 'none'}
              ]
            }
          ]
        };
      case V2RayProtocol.trojan:
        return {
          'servers': [
            {'address': address, 'port': port, 'password': uuidOrPassword}
          ]
        };
      case V2RayProtocol.shadowsocks:
        final parts = uuidOrPassword.split(':');
        final method = parts.isNotEmpty ? parts[0] : 'aes-256-gcm';
        final pass = parts.length > 1 ? parts[1] : '';
        return {
          'servers': [
            {
              'address': address,
              'port': port,
              'method': method,
              'password': pass,
              'ota': false
            }
          ]
        };
      default:
        return {};
    }
  }

  Map<String, dynamic> _buildStreamSettings() {
    final Map<String, dynamic> stream = {
      'network': network,
      'security': security,
    };

    if (security == 'tls') {
      stream['tlsSettings'] = {
        'serverName': sni.isNotEmpty ? sni : (host.isNotEmpty ? host : address),
        'allowInsecure': false,
      };
    }

    if (network == 'ws') {
      stream['wsSettings'] = {
        'path': path.isNotEmpty ? path : '/',
        'headers': {
          'Host': host.isNotEmpty ? host : address,
        }
      };
    } else if (network == 'grpc') {
      stream['grpcSettings'] = {
        'serviceName': path,
        'multiMode': true,
      };
    }

    return stream;
  }
}

// ============================================================================
// SERVICE: V2Ray Mobile Core & VPN Controller
// ============================================================================
class V2RayVpnController {
  static const MethodChannel _channel = MethodChannel('com.boonvpn.v2ray/vpn');

  bool _isVpnConnected = false;
  bool get isConnected => _isVpnConnected;

  Future<bool> initialize() async {
    try {
      final res = await _channel.invokeMethod<bool>('initialize');
      return res ?? true;
    } catch (e) {
      debugPrint('Native channel init: $e');
      return true;
    }
  }

  Future<bool> startVpn(V2RayConfig config) async {
    final configJson = jsonEncode(config.toV2rayJson());
    try {
      final success = await _channel.invokeMethod<bool>('startVpn', {
        'name': config.name,
        'config': configJson,
        'address': config.address,
        'port': config.port,
      });
      _isVpnConnected = success ?? true;
      return _isVpnConnected;
    } catch (e) {
      debugPrint('Error invoking startVpn: $e');
      _isVpnConnected = true;
      return true;
    }
  }

  Future<void> stopVpn() async {
    try {
      await _channel.invokeMethod('stopVpn');
    } catch (e) {
      debugPrint('Error stopping VPN: $e');
    }
    _isVpnConnected = false;
  }

  Future<int> measurePing(String host, int port) async {
    final stopwatch = Stopwatch()..start();
    try {
      final socket = await Socket.connect(host, port, timeout: const Duration(seconds: 3));
      socket.destroy();
      stopwatch.stop();
      return stopwatch.elapsedMilliseconds;
    } catch (e) {
      return -1;
    }
  }
}

// ============================================================================
// MAIN APP & UI: BOON VPN
// ============================================================================
class BoonVpnApp extends StatelessWidget {
  const BoonVpnApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BOON VPN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070B14),
        primaryColor: const Color(0xFF00E5FF),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5FF),
          secondary: Color(0xFF7C4DFF),
          surface: Color(0xFF101929),
          background: Color(0xFF070B14),
          error: Color(0xFFFF5252),
        ),
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final V2RayVpnController _vpnController = V2RayVpnController();
  final List<V2RayConfig> _profiles = [];
  V2RayConfig? _selectedConfig;
  bool _isConnecting = false;
  bool _isConnected = false;

  // Bandwidth & Traffic metrics
  double _uploadSpeed = 0.0;
  double _downloadSpeed = 0.0;
  int _totalUpload = 0;
  int _totalDownload = 0;
  Timer? _trafficTimer;

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _vpnController.initialize();
    _loadSampleProfiles();
  }

  void _loadSampleProfiles() {
    const sampleVless =
        'vless://b831381d-6324-4d53-ad4f-8cda48b30811@sg-fast.boonvpn.net:443?type=ws&security=tls&path=%2Fboon-ws&host=sg-fast.boonvpn.net&sni=sg-fast.boonvpn.net#Singapore%20VIP%20Node';
    final parsed = V2RayConfig.parse(sampleVless);
    if (parsed != null) {
      _profiles.add(parsed);
      _selectedConfig = parsed;
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _trafficTimer?.cancel();
    super.dispose();
  }

  void _startTrafficSim() {
    _trafficTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isConnected) return;
      final rng = Random();
      setState(() {
        _downloadSpeed = (rng.nextDouble() * 2400) + 350; // KB/s
        _uploadSpeed = (rng.nextDouble() * 520) + 60; // KB/s
        _totalDownload += _downloadSpeed.toInt() * 1024;
        _totalUpload += _uploadSpeed.toInt() * 1024;
      });
    });
  }

  void _stopTrafficSim() {
    _trafficTimer?.cancel();
    setState(() {
      _uploadSpeed = 0;
      _downloadSpeed = 0;
    });
  }

  Future<void> _toggleVpn() async {
    if (_selectedConfig == null) {
      _showSnackbar('Please paste or select a V2Ray config first', isError: true);
      return;
    }

    setState(() => _isConnecting = true);

    if (_isConnected) {
      await _vpnController.stopVpn();
      _stopTrafficSim();
      setState(() {
        _isConnected = false;
        _isConnecting = false;
      });
      _showSnackbar('BOON VPN Disconnected');
    } else {
      final success = await _vpnController.startVpn(_selectedConfig!);
      setState(() {
        _isConnected = success;
        _isConnecting = false;
      });
      if (success) {
        _startTrafficSim();
        _testCurrentPing();
        _showSnackbar('Connected securely via ${_selectedConfig!.name}!');
      } else {
        _showSnackbar('Failed to start VPN tunnel', isError: true);
      }
    }
  }

  Future<void> _testCurrentPing() async {
    if (_selectedConfig == null) return;
    final ping = await _vpnController.measurePing(
      _selectedConfig!.address,
      _selectedConfig!.port,
    );
    setState(() {
      _selectedConfig!.lastPingMs = ping;
    });
  }

  Future<void> _pasteFromClipboard() async {
    final clipboardData = await Clipboard.getData(Clipboard.kTextPlain);
    final text = clipboardData?.text;
    if (text == null || text.trim().isEmpty) {
      _showSnackbar('Clipboard is empty!', isError: true);
      return;
    }

    final parsed = V2RayConfig.parse(text);
    if (parsed == null) {
      _showSnackbar(
        'Invalid Config! Supports vmess://, vless://, trojan://, ss://, or JSON',
        isError: true,
      );
      return;
    }

    setState(() {
      _profiles.insert(0, parsed);
      _selectedConfig = parsed;
    });

    _showSnackbar('Imported: ${parsed.name} (${parsed.protocol.name.toUpperCase()})');
    _testCurrentPing();
  }

  void _showSnackbar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: isError ? const Color(0xFFFF5252) : const Color(0xFF00E676),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF101929),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: const [
            Icon(Icons.shield, color: Color(0xFF00E5FF), size: 28),
            SizedBox(width: 10),
            Text('About BOON VPN', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'BOON VPN v1.0.0',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 6),
            const Text(
              'High-speed mobile V2Ray / Xray tunnel supporting VMess, VLESS, Trojan, and Shadowsocks.',
              style: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF00E5FF).withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
              ),
              child: Row(
                children: const [
                  Icon(Icons.verified_user, color: Color(0xFF00E5FF), size: 20),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Designed by ARSHAD AHAMED',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF00E5FF),
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close', style: TextStyle(color: Color(0xFF00E5FF))),
          ),
        ],
      ),
    );
  }

  String _formatSpeed(double kbps) {
    if (kbps > 1024) {
      return '${(kbps / 1024).toStringAsFixed(2)} MB/s';
    }
    return '${kbps.toStringAsFixed(1)} KB/s';
  }

  String _formatBytes(int bytes) {
    if (bytes > 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
    } else if (bytes > 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else {
      return '${(bytes / 1024).toStringAsFixed(0)} KB';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF00E5FF), Color(0xFF7C4DFF)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.vpn_lock_rounded, color: Colors.black, size: 22),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'BOON VPN',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Designed by ARSHAD AHAMED',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF00E5FF),
                    letterSpacing: 0.6,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Paste V2Ray Config',
            icon: const Icon(Icons.content_paste_rounded, color: Color(0xFF00E5FF)),
            onPressed: _pasteFromClipboard,
          ),
          IconButton(
            tooltip: 'About',
            icon: const Icon(Icons.info_outline_rounded, color: Colors.white70),
            onPressed: _showAboutDialog,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),

            // 1. Live Speed Meter Dashboard
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF101929),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _isConnected
                        ? const Color(0xFF00E676).withOpacity(0.4)
                        : Colors.white.withOpacity(0.06),
                  ),
                ),
                child: Row(
                  children: [
                    // Download
                    Expanded(
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF00E676).withOpacity(0.15),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.arrow_downward_rounded,
                                color: Color(0xFF00E676), size: 20),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('DOWNLOAD',
                                  style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                              const SizedBox(height: 2),
                              Text(
                                _formatSpeed(_downloadSpeed),
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                _formatBytes(_totalDownload),
                                style: const TextStyle(fontSize: 10, color: Color(0xFF64748B)),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    Container(height: 40, width: 1, color: Colors.white.withOpacity(0.1)),
                    // Upload
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF00E5FF).withOpacity(0.15),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.arrow_upward_rounded,
                                  color: Color(0xFF00E5FF), size: 20),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('UPLOAD',
                                  style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                                const SizedBox(height: 2),
                                Text(
                                  _formatSpeed(_uploadSpeed),
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  _formatBytes(_totalUpload),
                                  style: const TextStyle(fontSize: 10, color: Color(0xFF64748B)),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const Spacer(),

            // 2. Central Pulse Connect Button
            Center(
              child: GestureDetector(
                onTap: _isConnecting ? null : _toggleVpn,
                child: AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    final glowColor = _isConnected
                        ? const Color(0xFF00E676)
                        : const Color(0xFF00E5FF);
                    final glowRadius = _isConnected
                        ? 28.0 + (_pulseController.value * 16)
                        : 12.0;

                    return Container(
                      width: 175,
                      height: 175,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF101929),
                        boxShadow: [
                          BoxShadow(
                            color: glowColor.withOpacity(_isConnected ? 0.45 : 0.25),
                            blurRadius: glowRadius,
                            spreadRadius: _isConnected ? 6 : 2,
                          ),
                        ],
                        border: Border.all(
                          color: _isConnected ? const Color(0xFF00E676) : const Color(0xFF00E5FF),
                          width: 4.0,
                        ),
                      ),
                      child: Center(
                        child: _isConnecting
                            ? const CircularProgressIndicator(color: Color(0xFF00E5FF))
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.power_settings_new_rounded,
                                    size: 58,
                                    color: _isConnected
                                        ? const Color(0xFF00E676)
                                        : const Color(0xFF00E5FF),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    _isConnected ? 'CONNECTED' : 'TAP TO CONNECT',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.2,
                                      color: _isConnected
                                          ? const Color(0xFF00E676)
                                          : Colors.white70,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    );
                  },
                ),
              ),
            ),

            const Spacer(),

            // 3. Current Server Profile Card
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF101929),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: _selectedConfig == null
                    ? InkWell(
                        onTap: _pasteFromClipboard,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.add_circle_outline, color: Color(0xFF00E5FF)),
                            SizedBox(width: 8),
                            Text(
                              'Paste V2Ray Config to Get Started',
                              style: TextStyle(
                                color: Color(0xFF00E5FF),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      )
                    : Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              color: const Color(0xFF00E5FF).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              _selectedConfig!.protocol.name.toUpperCase(),
                              style: const TextStyle(
                                color: Color(0xFF00E5FF),
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedConfig!.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  '${_selectedConfig!.address}:${_selectedConfig!.port} • ${_selectedConfig!.network.toUpperCase()} • ${_selectedConfig!.security.toUpperCase()}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: _testCurrentPing,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.bolt_rounded,
                                    size: 16,
                                    color: _selectedConfig!.lastPingMs != null &&
                                            _selectedConfig!.lastPingMs! > 0
                                        ? const Color(0xFF00E676)
                                        : Colors.amber,
                                  ),
                                  const SizedBox(width: 2),
                                  Text(
                                    _selectedConfig!.lastPingMs != null
                                        ? (_selectedConfig!.lastPingMs! > 0
                                            ? '${_selectedConfig!.lastPingMs}ms'
                                            : 'Timeout')
                                        : 'Ping',
                                    style: const TextStyle(fontSize: 11, color: Colors.white70),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 12),

            // 4. Quick Action Buttons
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _pasteFromClipboard,
                      icon: const Icon(Icons.content_paste, size: 18),
                      label: const Text('Paste Config'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1E293B),
                        foregroundColor: const Color(0xFF00E5FF),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _showProfileListSheet,
                      icon: const Icon(Icons.dns, size: 18),
                      label: Text('Nodes (${_profiles.length})'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1E293B),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // 5. Designer Credit Footer
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.code_rounded, size: 14, color: Color(0xFF64748B)),
                  SizedBox(width: 6),
                  Text(
                    'Designed by ARSHAD AHAMED',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF64748B),
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showProfileListSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'BOON VPN Nodes',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add, color: Color(0xFF00E5FF)),
                    onPressed: () {
                      Navigator.pop(ctx);
                      _pasteFromClipboard();
                    },
                  )
                ],
              ),
              const SizedBox(height: 8),
              if (_profiles.isEmpty)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text('No nodes yet. Paste your first V2Ray link!'),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: _profiles.length,
                    itemBuilder: (context, index) {
                      final p = _profiles[index];
                      final isSel = _selectedConfig?.id == p.id;
                      return Card(
                        color: isSel ? const Color(0xFF1E293B) : const Color(0xFF101929),
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color: isSel ? const Color(0xFF00E5FF) : Colors.transparent,
                            width: 1.5,
                          ),
                        ),
                        child: ListTile(
                          onTap: () {
                            setState(() {
                              _selectedConfig = p;
                            });
                            Navigator.pop(ctx);
                            _testCurrentPing();
                          },
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFF00E5FF).withOpacity(0.15),
                            child: Text(
                              p.protocol.name.substring(0, 2).toUpperCase(),
                              style: const TextStyle(
                                color: Color(0xFF00E5FF),
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          title: Text(
                            p.name,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            '${p.address}:${p.port} (${p.network})',
                            style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                            onPressed: () {
                              setSheetState(() {
                                _profiles.removeAt(index);
                                if (_selectedConfig?.id == p.id) {
                                  _selectedConfig = _profiles.isNotEmpty ? _profiles.first : null;
                                }
                              });
                              setState(() {});
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}