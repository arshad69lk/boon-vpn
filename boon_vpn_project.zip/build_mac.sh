#!/bin/bash
# ==============================================================================
# BOON VPN - Automated Build Script for macOS
# Designed by ARSHAD AHAMED
# ==============================================================================

set -e

echo "=================================================="
echo "  🚀 Building BOON VPN (Designed by ARSHAD AHAMED)"
echo "=================================================="

# 1. Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter not found! Installing via Homebrew..."
    if ! command -v brew &> /dev/null; then
        echo "Please install Homebrew first from https://brew.sh or download Flutter SDK directly."
        exit 1
    fi
    brew install --cask flutter
fi

echo "✅ Flutter detected: "

# 2. Get dependencies
echo "📦 Fetching dependencies..."
flutter pub get

# 3. Build release APK
echo "🔨 Compiling release APK for Android..."
flutter build apk --release --target-platform android-arm64

echo ""
echo "=================================================="
echo "🎉 SUCCESS! BOON VPN APK is ready!"
echo "📁 APK Location:"
echo "/working_dir/c_e239dddd5beb3a52/build/app/outputs/flutter-apk/app-arm64-v8a-release.apk"
echo "=================================================="
echo "👉 AirDrop or send this APK to your Android phone to install!"
