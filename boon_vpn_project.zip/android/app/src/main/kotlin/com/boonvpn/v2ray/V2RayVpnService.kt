package com.boonvpn.v2ray

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream

class V2RayVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private var isRunning = false

    companion object {
        const val ACTION_START = "com.boonvpn.v2ray.START"
        const val ACTION_STOP = "com.boonvpn.v2ray.STOP"
        const val EXTRA_CONFIG = "EXTRA_CONFIG"
        const val EXTRA_NAME = "EXTRA_NAME"
        const val NOTIFICATION_CHANNEL_ID = "boon_vpn_channel"
        const val NOTIFICATION_ID = 2001
        const val VPN_MTU = 1500
        const val VPN_ADDRESS = "172.19.0.1"
        const val VPN_ROUTE = "0.0.0.0"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val configJson = intent.getStringExtra(EXTRA_CONFIG) ?: return START_NOT_STICKY
                val serverName = intent.getStringExtra(EXTRA_NAME) ?: "BOON VPN Node"
                startVpnTunnel(configJson, serverName)
            }
            ACTION_STOP -> {
                stopVpnTunnel()
            }
        }
        return START_STICKY
    }

    private fun startVpnTunnel(configJson: String, serverName: String) {
        if (isRunning) return
        isRunning = true
        startForeground(NOTIFICATION_ID, buildNotification("Connecting to ..."))

        serviceScope.launch {
            try {
                val configFile = File(filesDir, "config.json")
                FileOutputStream(configFile).use { out ->
                    out.write(configJson.toByteArray())
                }

                val builder = Builder()
                    .setSession("BOON VPN - ")
                    .setMtu(VPN_MTU)
                    .addAddress(VPN_ADDRESS, 24)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .addRoute(VPN_ROUTE, 0)

                vpnInterface = builder.establish()
                if (vpnInterface != null) {
                    updateNotification("Secured by BOON VPN | Designed by ARSHAD AHAMED")
                } else {
                    stopSelf()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                stopVpnTunnel()
            }
        }
    }

    private fun stopVpnTunnel() {
        if (!isRunning) return
        isRunning = false
        serviceScope.launch {
            try {
                vpnInterface?.close()
                vpnInterface = null
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                stopForeground(true)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "BOON VPN Tunnel Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows connection status for BOON VPN (Designed by ARSHAD AHAMED)"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("BOON VPN Active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }
}
