package com.boonvpn.v2ray

import android.content.Intent
import android.net.VpnService
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.boonvpn.v2ray/vpn"
    private val VPN_REQUEST_CODE = 0x0F

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "initialize" -> {
                    result.success(true)
                }
                "startVpn" -> {
                    val config = call.argument<String>("config")
                    val name = call.argument<String>("name")
                    val intent = VpnService.prepare(this)
                    if (intent != null) {
                        startActivityForResult(intent, VPN_REQUEST_CODE)
                    } else {
                        val serviceIntent = Intent(this, V2RayVpnService::class.java).apply {
                            action = V2RayVpnService.ACTION_START
                            putExtra(V2RayVpnService.EXTRA_CONFIG, config)
                            putExtra(V2RayVpnService.EXTRA_NAME, name)
                        }
                        startService(serviceIntent)
                    }
                    result.success(true)
                }
                "stopVpn" -> {
                    val serviceIntent = Intent(this, V2RayVpnService::class.java).apply {
                        action = V2RayVpnService.ACTION_STOP
                    }
                    startService(serviceIntent)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }
}
