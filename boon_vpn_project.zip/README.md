# BOON VPN

> **Designed by ARSHAD AHAMED**

A sleek, high-performance mobile V2Ray / Xray VPN client for Android & iOS.

## Features
- **1-Tap Paste Config**: Auto-parses , , , , and custom JSON.
- **Branded & Customized**: Features full "Designed by ARSHAD AHAMED" branding.
- **Ultra-Smooth UI**: 60/120 FPS hardware acceleration with real-time speed metrics and latency test.
- **Android VpnService**: Low-latency kernel-level packet tunneling.

## How to Build on Mac
Open Terminal in this folder and run:

Or manually:

Your APK will be in .
